/*
KHOA LUONG
KLUON7
1366739
CMPS180 LAB2
*/
select Name, SSN
from Persons
where Salary>20000.00;
